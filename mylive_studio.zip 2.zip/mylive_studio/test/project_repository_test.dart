import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mylive_studio/core/storage/memory_project_store.dart';
import 'package:mylive_studio/features/editor/models/layer.dart';
import 'package:mylive_studio/features/project/services/project_repository.dart';

void main() {
  late MemoryProjectStore store;
  late ProjectRepository repo;

  setUp(() {
    store = MemoryProjectStore();
    repo = ProjectRepository(store);
  });

  ImportedImage img(String name, int w, int h) => ImportedImage(
      name: name, bytes: Uint8List.fromList([1, 2, 3]), width: w, height: h);

  test('cria e lista projetos', () async {
    await repo.createProject(name: ' A ', width: 100, height: 50);
    final list = await repo.listProjects();
    expect(list.length, 1);
    expect(list.first.name, 'A');
  });

  test('rejeita nome vazio e resolução inválida', () async {
    expect(() => repo.createProject(name: '  ', width: 10, height: 10),
        throwsA(isA<ProjectException>()));
    expect(() => repo.createProject(name: 'x', width: 0, height: 10),
        throwsA(isA<ProjectException>()));
  });

  test('renomeia e exclui', () async {
    final m = await repo.createProject(name: 'A', width: 10, height: 10);
    await repo.renameProject(m.id, 'B');
    expect((await repo.getProject(m.id)).name, 'B');
    await repo.deleteProject(m.id);
    expect(await repo.listProjects(), isEmpty);
  });

  test('salva e recarrega camadas com transformações', () async {
    final m = await repo.createProject(name: 'A', width: 200, height: 100);
    final doc = await repo.loadDocument(m.id);
    doc.layers.add(Layer(
        id: 'l1',
        name: 'Cabelo',
        kind: LayerKind.image,
        x: 10,
        y: 20,
        scale: 1.5,
        rotation: 0.3,
        opacity: 0.5,
        locked: true));
    await repo.saveDocument(m.id, doc);
    final back = await repo.loadDocument(m.id);
    expect(back.layers.single.name, 'Cabelo');
    expect(back.layers.single.rotation, 0.3);
    expect(back.layers.single.opacity, 0.5);
    expect(back.layers.single.locked, true);
  });

  test('imagem inicial vira camada e asset', () async {
    final m = await repo.createProject(
        name: 'A', width: 100, height: 100, initialImage: img('foto.png', 200, 50));
    final doc = await repo.loadDocument(m.id);
    expect(doc.layers.single.name, 'foto');
    expect(doc.layers.single.scale, 0.5);
    final bytes = await repo.loadAsset(m.id, doc.layers.single.imagePath!);
    expect(bytes.length, 3);
  });

  test('recupera do backup se o principal estiver corrompido', () async {
    final m = await repo.createProject(name: 'A', width: 10, height: 10);
    await repo.saveDocument(m.id, await repo.loadDocument(m.id));
    store.corruptMain(m.id);
    expect((await repo.loadDocument(m.id)).width, 10);
  });

  test('recusa formato não suportado', () async {
    final m = await repo.createProject(name: 'A', width: 10, height: 10);
    expect(() => repo.importImage(m.id, 'x.gif', Uint8List.fromList([0])),
        throwsA(isA<ProjectException>()));
  });
}

import 'dart:ui' show Offset;

import 'package:flutter_test/flutter_test.dart';
import 'package:mylive_studio/core/storage/memory_project_store.dart';
import 'package:mylive_studio/features/editor/models/layer.dart';
import 'package:mylive_studio/features/editor/state/editor_controller.dart';
import 'package:mylive_studio/features/project/services/project_repository.dart';

Layer imageLayer(String id, {String? parent}) => Layer(
    id: id,
    name: id,
    kind: LayerKind.image,
    parentId: parent,
    naturalWidth: 100,
    naturalHeight: 50,
    x: 50,
    y: 50);

void main() {
  late ProjectRepository repo;
  late EditorController c;

  setUp(() async {
    repo = ProjectRepository(MemoryProjectStore());
    final meta = await repo.createProject(name: 'T', width: 400, height: 300);
    c = EditorController(
        repository: repo, meta: meta, doc: await repo.loadDocument(meta.id));
  });

  tearDown(() => c.dispose());

  test('inserir, desfazer e refazer', () {
    c.insertLayer(imageLayer('a'));
    expect(c.layers.length, 1);
    c.undo();
    expect(c.layers, isEmpty);
    c.redo();
    expect(c.layers.single.id, 'a');
  });

  test('transformação em gesto é um único passo de histórico', () {
    c.insertLayer(imageLayer('a'));
    c.beginGesture();
    c.moveSelectedBy(10, 0);
    c.moveSelectedBy(10, 0);
    expect(c.selected!.x, 70);
    c.undo();
    expect(c.selected!.x, 50);
  });

  test('camada bloqueada não move', () {
    c.insertLayer(imageLayer('a'));
    c.toggleLock('a');
    c.moveSelectedBy(10, 10);
    expect(c.selected!.x, 50);
  });

  test('duplicar, ocultar e excluir', () {
    c.insertLayer(imageLayer('a'));
    c.duplicate('a');
    expect(c.layers.length, 2);
    c.toggleVisible('a');
    expect(c.effectivelyVisible(c.layerById('a')!), false);
    c.deleteLayer('a');
    expect(c.layers.length, 1);
  });

  test('reordenar', () {
    c.insertLayer(imageLayer('a'));
    c.insertLayer(imageLayer('b'));
    c.moveLayer(0, 1);
    expect(c.layers.map((l) => l.id).toList(), ['b', 'a']);
  });

  test('pasta: agrupar, ocultar herdado e impedir ciclo', () {
    c.insertLayer(imageLayer('a'));
    c.groupLayer('a');
    final g = c.layers.firstWhere((l) => l.kind == LayerKind.group);
    expect(c.layerById('a')!.parentId, g.id);
    c.toggleVisible(g.id);
    expect(c.effectivelyVisible(c.layerById('a')!), false);
    expect(c.moveToGroup(g.id, g.id), false);
    c.select(null);
    c.addGroup('Outra');
    final other = c.layers.last;
    expect(c.moveToGroup(g.id, other.id), true);
    expect(c.moveToGroup(other.id, g.id), false);
  });

  test('hitTest respeita posição e rotação', () {
    final l = imageLayer('a')..rotation = 1.5707963;
    c.insertLayer(l);
    expect(c.hitTest(const Offset(50, 50))?.id, 'a');
    // após girar 90°, o retângulo 100x50 vira 50x100
    expect(c.hitTest(const Offset(50, 95)), isNotNull);
    expect(c.hitTest(const Offset(95, 50)), isNull);
  });

  test('salvar persiste no repositório', () async {
    c.insertLayer(imageLayer('a'));
    await c.save();
    expect(c.dirty, false);
    final back = await repo.loadDocument(c.meta.id);
    expect(back.layers.single.id, 'a');
  });
}

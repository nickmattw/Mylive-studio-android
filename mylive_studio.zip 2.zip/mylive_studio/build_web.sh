#!/usr/bin/env bash
# Compila a versão Web e (opcional) serve localmente.
# Uso: ./build_web.sh            -> compila em build/web (base href "/")
#      ./build_web.sh serve      -> compila e serve em http://localhost:8080
set -euo pipefail
cd "$(dirname "$0")"
flutter create --platforms=web,android --org com.mylive --project-name mylive_studio .
flutter pub get
flutter test
flutter build web --release
touch build/web/.nojekyll
echo "Web compilada em: build/web"
if [ "${1:-}" = "serve" ]; then
  echo "Abra http://localhost:8080"
  python3 -m http.server 8080 -d build/web
fi

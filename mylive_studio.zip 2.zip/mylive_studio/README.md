# MyLive Studio (Android + Web)

Editor 2D com camadas, escrito em Flutter. A mesma base de código gera o
app Android (APK) e a versão Web/PWA.

## Aviso importante
Todo o código foi escrito SEM Flutter instalado: nunca foi compilado nem
testado. Podem existir erros de compilação ou bugs na primeira execução.
Requer Flutter estável 3.22 ou mais novo.

## Funcionalidades
- Tela inicial, criação, renomear e excluir projetos, miniaturas.
- Importação PNG/JPG (transparência preservada: guarda os bytes originais).
- Editor: canvas com quadriculado, zoom (pinça/roda), mover a tela,
  seleção por toque, mover, escala+rotação pela alça roxa, sliders de
  posição/escala/rotação/opacidade, guias, painéis recolhíveis.
- Camadas: criar pasta, importar, duplicar, renomear, ocultar, bloquear,
  excluir, reordenar (arrastar), agrupar/mover para pasta.
- Desfazer/refazer (100 níveis), autosave (2 s), salvar ao voltar.

## Armazenamento (independente de plataforma)
`lib/core/storage/project_store.dart` define a interface.
- Web: Sembast sobre IndexedDB (`SembastProjectStore`).
- Android/desktop: SQLite + arquivos (`SqliteProjectStore`).
- Testes: `MemoryProjectStore`.
A escolha é automática por import condicional (`store_factory.dart`).
Os dados da Web ficam no navegador/dispositivo em uso (não são enviados
a nenhum servidor).

## Pastas de plataforma
`android/` não vem no projeto: é gerada por
`flutter create --platforms=web,android --org com.mylive --project-name mylive_studio .`
(feito automaticamente pelos scripts e workflows; não sobrescreve lib/,
web/ nem pubspec.yaml).

## Compilar Web no computador
    ./build_web.sh          # gera build/web
    ./build_web.sh serve    # e abre em http://localhost:8080

## Publicar no GitHub Pages (gera o endereço real)
1. Crie um repositório no GitHub e envie TODO o conteúdo desta pasta
   (incluindo a pasta oculta .github) para a branch `main`.
2. No repositório: Settings > Pages > Build and deployment > Source:
   escolha "GitHub Actions".
3. Aba Actions > "Deploy Web (GitHub Pages)" > Run workflow (ou faça um push).
4. Ao terminar, o endereço aparece no job "deploy" e em Settings > Pages.
   Formato: https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/
   (se o repositório se chamar SEU-USUARIO.github.io, o base href precisa
   ser "/": troque `--base-href` no workflow por `"/"`.)
Repositórios privados só têm Pages em planos pagos.

## Acessar pelo celular (Chrome Android)
1. Abra o endereço do Pages no Chrome.
2. Menu ⋮ > "Instalar app" / "Adicionar à tela inicial" (PWA).
3. Funciona em tela cheia; projetos ficam salvos neste navegador.
Limpar dados do site apaga os projetos. A primeira abertura baixa o
CanvasKit (precisa de internet); modo offline completo não foi validado.

## APK Android
    ./build_apk.sh                  # debug
ou o workflow `.github/workflows/build-apk.yml` (artefato mylive-studio-debug-apk).

## Testes
`flutter test` (repositório e controlador do editor, sem SQLite nativo).

## Verificação manual
Web/Android: criar projeto, importar PNG com transparência, arrastar,
pinçar, usar alça roxa, sliders, ocultar/bloquear/duplicar/reordenar,
criar pasta, desfazer/refazer, voltar, reabrir e conferir persistência;
testar em retrato/paisagem e em tela larga.

## Pendente
Exportar imagem, PSD, Mesh/Deformer/Rigging/Parâmetros/Física/Animação,
configurações do app, timeline.

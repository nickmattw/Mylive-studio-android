import 'package:flutter/material.dart';

class AppColors {
  static const black = Color(0xFF0B0B0F);
  static const graphite = Color(0xFF17171E);
  static const panel = Color(0xFF1F1F29);
  static const purple = Color(0xFF8B5CF6);
  static const violetBlue = Color(0xFF6366F1);
  static const text = Color(0xFFE8E8F0);
  static const textDim = Color(0xFF9A9AB0);
}

class AppTheme {
  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.black,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.purple,
          secondary: AppColors.violetBlue,
          surface: AppColors.graphite,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.graphite,
          elevation: 0,
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size(48, 48),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
      );
}

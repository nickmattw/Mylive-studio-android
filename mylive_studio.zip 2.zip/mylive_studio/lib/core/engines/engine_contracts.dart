/// Contratos dos motores futuros. Sem implementação falsa: cada motor
/// será implementado (Dart ou C++ via FFI/JNI) em etapas posteriores.
abstract class Engine {
  String get name;
  Future<void> initialize();
  Future<void> dispose();
}

abstract class MeshEngine extends Engine {}
abstract class DeformerEngine extends Engine {}
abstract class RiggingEngine extends Engine {}
abstract class ParameterEngine extends Engine {}
abstract class PhysicsEngine extends Engine {}
abstract class AnimationEngine extends Engine {}
abstract class RenderingEngine extends Engine {}
abstract class ProjectEngine extends Engine {}

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.size = 44});

  final double size;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(size * 0.3),
              gradient: const LinearGradient(
                colors: [AppColors.purple, AppColors.violetBlue],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Icon(Icons.layers_outlined,
                color: Colors.white, size: size * 0.55),
          ),
          const SizedBox(width: 12),
          Text.rich(
            TextSpan(children: [
              TextSpan(
                text: 'MyLive ',
                style: TextStyle(
                    fontSize: size * 0.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.text),
              ),
              TextSpan(
                text: 'Studio',
                style: TextStyle(
                    fontSize: size * 0.5,
                    fontWeight: FontWeight.w300,
                    color: AppColors.purple),
              ),
            ]),
          ),
        ],
      );
}

import 'package:flutter/material.dart';

/// Fundo quadriculado usado para indicar transparência.
class Checkerboard extends StatelessWidget {
  const Checkerboard({super.key, this.tile = 14});

  final double tile;

  @override
  Widget build(BuildContext context) =>
      CustomPaint(painter: _CheckerPainter(tile), size: Size.infinite);
}

class _CheckerPainter extends CustomPainter {
  _CheckerPainter(this.tile);
  final double tile;

  @override
  void paint(Canvas canvas, Size size) {
    final a = Paint()..color = const Color(0xFF2A2A35);
    final b = Paint()..color = const Color(0xFF21212A);
    canvas.drawRect(Offset.zero & size, b);
    final cols = (size.width / tile).ceil();
    final rows = (size.height / tile).ceil();
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        if ((r + c).isEven) {
          canvas.drawRect(Rect.fromLTWH(c * tile, r * tile, tile, tile), a);
        }
      }
    }
  }

  @override
  bool shouldRepaint(_CheckerPainter old) => old.tile != tile;
}

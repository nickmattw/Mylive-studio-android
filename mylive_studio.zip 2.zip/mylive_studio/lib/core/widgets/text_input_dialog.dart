import 'package:flutter/material.dart';

/// Diálogo simples de entrada de texto. Retorna null se cancelado.
Future<String?> showTextInputDialog(
  BuildContext context, {
  required String title,
  String initial = '',
  String confirmLabel = 'Salvar',
}) =>
    showDialog<String>(
      context: context,
      builder: (_) => _TextInputDialog(
          title: title, initial: initial, confirmLabel: confirmLabel),
    );

class _TextInputDialog extends StatefulWidget {
  const _TextInputDialog(
      {required this.title, required this.initial, required this.confirmLabel});
  final String title, initial, confirmLabel;

  @override
  State<_TextInputDialog> createState() => _TextInputDialogState();
}

class _TextInputDialogState extends State<_TextInputDialog> {
  late final TextEditingController _c =
      TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _submit() {
    final v = _c.text.trim();
    if (v.isEmpty) return;
    Navigator.pop(context, v);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.title),
        content: TextField(
          controller: _c,
          autofocus: true,
          onSubmitted: (_) => _submit(),
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar')),
          FilledButton(onPressed: _submit, child: Text(widget.confirmLabel)),
        ],
      );
}

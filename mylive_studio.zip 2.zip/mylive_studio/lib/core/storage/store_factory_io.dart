import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'project_store.dart';
import 'sqlite_project_store.dart';

Future<ProjectStore> createProjectStore() async {
  final docs = await getApplicationDocumentsDirectory();
  final root = Directory(p.join(docs.path, 'projects'));
  await root.create(recursive: true);
  return SqliteProjectStore.open(root);
}

import 'package:sembast_web/sembast_web.dart';

import 'project_store.dart';
import 'sembast_project_store.dart';

Future<ProjectStore> createProjectStore() =>
    SembastProjectStore.open(databaseFactoryWeb, 'mylive_studio');

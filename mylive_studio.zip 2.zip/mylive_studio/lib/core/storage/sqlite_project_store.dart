import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../../features/project/models/project_meta.dart';
import 'project_store.dart';

/// Android/desktop: índice no SQLite + arquivos em disco:
/// <root>/<id>/project.json (+ .bak) e <root>/<id>/assets/*
/// (mesmo formato de pastas da Parte 2).
class SqliteProjectStore implements ProjectStore {
  SqliteProjectStore._(this._db, this.root);

  final Database _db;
  final Directory root;
  static const _table = 'projects';

  static Future<SqliteProjectStore> open(Directory root) async {
    final dbPath = p.join(await getDatabasesPath(), 'mylive_studio.db');
    final db = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            width INTEGER NOT NULL,
            height INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            modified_at INTEGER NOT NULL,
            thumbnail_path TEXT
          )
        ''');
        await db.execute(
            'CREATE INDEX idx_projects_modified ON projects(modified_at DESC)');
      },
    );
    return SqliteProjectStore._(db, root);
  }

  Directory _dir(String id) => Directory(p.join(root.path, id));
  File _docFile(String id) => File(p.join(_dir(id).path, 'project.json'));

  @override
  Future<List<ProjectMeta>> listProjects() async {
    final rows = await _db.query(_table, orderBy: 'modified_at DESC');
    return rows.map(ProjectMeta.fromMap).toList();
  }

  @override
  Future<ProjectMeta?> getProject(String id) async {
    final rows = await _db.query(_table, where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : ProjectMeta.fromMap(rows.first);
  }

  @override
  Future<void> upsertProject(ProjectMeta meta) async {
    await _db.insert(_table, meta.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> deleteProject(String id) async {
    await _db.delete(_table, where: 'id = ?', whereArgs: [id]);
    final d = _dir(id);
    if (await d.exists()) await d.delete(recursive: true);
  }

  @override
  Future<void> writeDocument(String id, String json) async {
    await _dir(id).create(recursive: true);
    final file = _docFile(id);
    final tmp = File('${file.path}.tmp');
    await tmp.writeAsString(json, flush: true);
    if (await file.exists()) await file.copy('${file.path}.bak');
    await tmp.rename(file.path);
  }

  @override
  Future<List<String>> readDocumentCandidates(String id) async {
    final main = _docFile(id);
    final out = <String>[];
    for (final f in [main, File('${main.path}.bak')]) {
      if (await f.exists()) out.add(await f.readAsString());
    }
    return out;
  }

  @override
  Future<void> putAsset(String id, String path, Uint8List bytes) async {
    final f = File(p.join(_dir(id).path, path));
    await f.parent.create(recursive: true);
    await f.writeAsBytes(bytes, flush: true);
  }

  @override
  Future<Uint8List?> getAsset(String id, String path) async {
    final f = File(p.join(_dir(id).path, path));
    if (!await f.exists()) return null;
    return f.readAsBytes();
  }

  @override
  Future<void> close() => _db.close();
}

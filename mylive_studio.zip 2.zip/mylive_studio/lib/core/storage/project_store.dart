import 'dart:typed_data';

import '../../features/project/models/project_meta.dart';

/// Camada de armazenamento independente de plataforma.
/// Implementações: SqliteProjectStore (Android/desktop), SembastProjectStore
/// (Web/IndexedDB) e MemoryProjectStore (testes).
abstract class ProjectStore {
  Future<List<ProjectMeta>> listProjects();
  Future<ProjectMeta?> getProject(String id);
  Future<void> upsertProject(ProjectMeta meta);

  /// Remove metadados, documento e todos os assets do projeto.
  Future<void> deleteProject(String id);

  /// Grava o documento JSON mantendo a versão anterior como backup.
  Future<void> writeDocument(String id, String json);

  /// Retorna [principal, backup] (somente os que existirem).
  Future<List<String>> readDocumentCandidates(String id);

  Future<void> putAsset(String id, String path, Uint8List bytes);
  Future<Uint8List?> getAsset(String id, String path);

  Future<void> close();
}

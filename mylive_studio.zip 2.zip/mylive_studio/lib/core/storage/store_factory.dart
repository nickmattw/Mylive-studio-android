// Seleciona a implementação de armazenamento conforme a plataforma:
// Web -> IndexedDB (Sembast); Android/desktop -> SQLite + arquivos.
export 'store_factory_stub.dart'
    if (dart.library.io) 'store_factory_io.dart'
    if (dart.library.js_interop) 'store_factory_web.dart';

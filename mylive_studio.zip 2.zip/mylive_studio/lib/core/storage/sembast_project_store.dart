import 'dart:convert';
import 'dart:typed_data';

import 'package:sembast/sembast.dart';

import '../../features/project/models/project_meta.dart';
import 'project_store.dart';

/// Armazenamento via Sembast. Na Web, o banco é persistido em IndexedDB
/// (use com databaseFactoryWeb). Imagens são guardadas em base64.
class SembastProjectStore implements ProjectStore {
  SembastProjectStore(this._db);

  final Database _db;

  static Future<SembastProjectStore> open(
      DatabaseFactory factory, String path) async {
    return SembastProjectStore(await factory.openDatabase(path));
  }

  final _projects = stringMapStoreFactory.store('projects');
  final _docs = stringMapStoreFactory.store('documents');
  final _assets = stringMapStoreFactory.store('assets');

  @override
  Future<List<ProjectMeta>> listProjects() async {
    final snaps = await _projects.find(_db,
        finder: Finder(sortOrders: [SortOrder('modified_at', false)]));
    return snaps.map((s) => ProjectMeta.fromMap(s.value)).toList();
  }

  @override
  Future<ProjectMeta?> getProject(String id) async {
    final v = await _projects.record(id).get(_db);
    return v == null ? null : ProjectMeta.fromMap(v);
  }

  @override
  Future<void> upsertProject(ProjectMeta meta) async {
    await _projects.record(meta.id).put(_db, meta.toMap());
  }

  @override
  Future<void> deleteProject(String id) async {
    await _db.transaction((txn) async {
      await _projects.record(id).delete(txn);
      await _docs.record(id).delete(txn);
      await _assets.delete(txn,
          finder: Finder(filter: Filter.equals('projectId', id)));
    });
  }

  @override
  Future<void> writeDocument(String id, String json) async {
    await _db.transaction((txn) async {
      final prev = await _docs.record(id).get(txn);
      final prevMain = prev?['main'] as String?;
      await _docs.record(id).put(txn, {
        'main': json,
        if (prevMain != null) 'backup': prevMain,
      });
    });
  }

  @override
  Future<List<String>> readDocumentCandidates(String id) async {
    final v = await _docs.record(id).get(_db);
    if (v == null) return [];
    return [v['main'], v['backup']].whereType<String>().toList();
  }

  @override
  Future<void> putAsset(String id, String path, Uint8List bytes) async {
    await _assets
        .record('$id/$path')
        .put(_db, {'projectId': id, 'data': base64Encode(bytes)});
  }

  @override
  Future<Uint8List?> getAsset(String id, String path) async {
    final v = await _assets.record('$id/$path').get(_db);
    if (v == null) return null;
    return base64Decode(v['data'] as String);
  }

  @override
  Future<void> close() => _db.close();
}

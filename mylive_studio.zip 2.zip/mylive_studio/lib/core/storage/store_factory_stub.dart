import 'project_store.dart';

Future<ProjectStore> createProjectStore() =>
    throw UnsupportedError('Plataforma sem armazenamento suportado.');

import 'dart:typed_data';

import '../../features/project/models/project_meta.dart';
import 'project_store.dart';

/// Armazenamento em memória (testes).
class MemoryProjectStore implements ProjectStore {
  final Map<String, ProjectMeta> _meta = {};
  final Map<String, String> _main = {};
  final Map<String, String> _backup = {};
  final Map<String, Uint8List> _assets = {};

  @override
  Future<List<ProjectMeta>> listProjects() async {
    final l = _meta.values.toList()
      ..sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    return l;
  }

  @override
  Future<ProjectMeta?> getProject(String id) async => _meta[id];

  @override
  Future<void> upsertProject(ProjectMeta meta) async => _meta[meta.id] = meta;

  @override
  Future<void> deleteProject(String id) async {
    _meta.remove(id);
    _main.remove(id);
    _backup.remove(id);
    _assets.removeWhere((k, _) => k.startsWith('$id/'));
  }

  @override
  Future<void> writeDocument(String id, String json) async {
    final prev = _main[id];
    if (prev != null) _backup[id] = prev;
    _main[id] = json;
  }

  @override
  Future<List<String>> readDocumentCandidates(String id) async =>
      [if (_main[id] != null) _main[id]!, if (_backup[id] != null) _backup[id]!];

  /// Somente para testes: simula corrupção do arquivo principal.
  void corruptMain(String id) => _main[id] = '{corrompido';

  @override
  Future<void> putAsset(String id, String path, Uint8List bytes) async =>
      _assets['$id/$path'] = bytes;

  @override
  Future<Uint8List?> getAsset(String id, String path) async =>
      _assets['$id/$path'];

  @override
  Future<void> close() async {}
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app.dart';
import 'core/storage/store_factory.dart';
import 'features/project/services/project_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  final store = await createProjectStore();
  runApp(MyLiveStudioApp(repository: ProjectRepository(store)));
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'features/home/state/home_controller.dart';
import 'features/home/ui/home_screen.dart';
import 'features/project/services/project_repository.dart';

class MyLiveStudioApp extends StatelessWidget {
  const MyLiveStudioApp({super.key, required this.repository});

  final ProjectRepository repository;

  @override
  Widget build(BuildContext context) => MultiProvider(
        providers: [
          Provider<ProjectRepository>.value(value: repository),
          ChangeNotifierProvider<HomeController>(
            create: (_) => HomeController(repository)..load(),
          ),
        ],
        child: MaterialApp(
          title: 'MyLive Studio',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.dark,
          home: const HomeScreen(),
        ),
      );
}

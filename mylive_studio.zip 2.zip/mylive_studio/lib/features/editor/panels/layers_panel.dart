import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/text_input_dialog.dart';
import '../models/layer.dart';
import '../state/editor_controller.dart';

class LayersPanel extends StatelessWidget {
  const LayersPanel({
    super.key,
    required this.onAddImage,
    required this.onClose,
  });

  final VoidCallback onAddImage, onClose;

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    final list = c.layers.reversed.toList();
    return Material(
      color: AppColors.graphite,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 4, 0),
            child: Row(
              children: [
                const Expanded(
                    child: Text('Camadas',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                IconButton(
                    tooltip: 'Importar imagem',
                    onPressed: onAddImage,
                    icon: const Icon(Icons.add_photo_alternate_outlined)),
                IconButton(
                    tooltip: 'Nova pasta',
                    onPressed: c.addGroup,
                    icon: const Icon(Icons.create_new_folder_outlined)),
                IconButton(
                    tooltip: 'Recolher painel',
                    onPressed: onClose,
                    icon: const Icon(Icons.chevron_left)),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: list.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text('Sem camadas. Importe uma imagem.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppColors.textDim)),
                    ),
                  )
                : ReorderableListView.builder(
                    buildDefaultDragHandles: false,
                    itemCount: list.length,
                    onReorder: (oldI, newI) {
                      if (newI > oldI) newI -= 1;
                      final n = list.length;
                      c.moveLayer(n - 1 - oldI, n - 1 - newI);
                    },
                    itemBuilder: (ctx, i) => _LayerTile(
                      key: ValueKey(list[i].id),
                      index: i,
                      layer: list[i],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _LayerTile extends StatelessWidget {
  const _LayerTile({super.key, required this.index, required this.layer});

  final int index;
  final Layer layer;

  Future<void> _action(BuildContext context, String a) async {
    final c = context.read<EditorController>();
    switch (a) {
      case 'rename':
        final n = await showTextInputDialog(context,
            title: 'Renomear camada', initial: layer.name);
        if (n != null) c.rename(layer.id, n);
      case 'duplicate':
        c.duplicate(layer.id);
      case 'delete':
        c.deleteLayer(layer.id);
      case 'group':
        c.groupLayer(layer.id);
      case 'move':
        await _moveToGroup(context, c);
      case 'out':
        c.moveToGroup(layer.id, null);
    }
  }

  Future<void> _moveToGroup(BuildContext context, EditorController c) async {
    final groups = c.layers
        .where((g) =>
            g.kind == LayerKind.group &&
            g.id != layer.id &&
            !c.isDescendant(g.id, layer.id))
        .toList();
    if (groups.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Crie uma pasta primeiro.')));
      return;
    }
    final chosen = await showModalBottomSheet<Layer>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            for (final g in groups)
              ListTile(
                leading: const Icon(Icons.folder_outlined),
                title: Text(g.name),
                onTap: () => Navigator.pop(ctx, g),
              ),
          ],
        ),
      ),
    );
    if (chosen != null) c.moveToGroup(layer.id, chosen.id);
  }

  @override
  Widget build(BuildContext context) {
    final c = context.read<EditorController>();
    final selected = context.select<EditorController, bool>(
        (e) => e.selectedId == layer.id);
    final depth = c.depthOf(layer);
    final isGroup = layer.kind == LayerKind.group;
    return Material(
      color: selected ? AppColors.purple.withAlpha(50) : Colors.transparent,
      child: InkWell(
        onTap: () => c.select(layer.id),
        child: Padding(
          padding: EdgeInsets.only(left: 8.0 + depth * 14),
          child: Row(
            children: [
              Icon(isGroup ? Icons.folder_outlined : Icons.image_outlined,
                  size: 20, color: AppColors.textDim),
              const SizedBox(width: 6),
              Expanded(
                child: Text(layer.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: layer.visible
                            ? AppColors.text
                            : AppColors.textDim)),
              ),
              _mini(
                  layer.visible
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  layer.visible ? 'Ocultar' : 'Mostrar',
                  () => c.toggleVisible(layer.id)),
              _mini(
                  layer.locked ? Icons.lock_outline : Icons.lock_open_outlined,
                  layer.locked ? 'Desbloquear' : 'Bloquear',
                  () => c.toggleLock(layer.id)),
              PopupMenuButton<String>(
                padding: EdgeInsets.zero,
                iconSize: 20,
                onSelected: (a) => _action(context, a),
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'rename', child: Text('Renomear')),
                  const PopupMenuItem(
                      value: 'duplicate', child: Text('Duplicar')),
                  const PopupMenuItem(
                      value: 'group', child: Text('Agrupar em nova pasta')),
                  const PopupMenuItem(
                      value: 'move', child: Text('Mover para pasta…')),
                  if (layer.parentId != null)
                    const PopupMenuItem(
                        value: 'out', child: Text('Tirar da pasta')),
                  const PopupMenuItem(value: 'delete', child: Text('Excluir')),
                ],
              ),
              ReorderableDragStartListener(
                index: index,
                child: const Padding(
                  padding: EdgeInsets.all(8),
                  child: Icon(Icons.drag_handle, size: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _mini(IconData icon, String tip, VoidCallback onTap) => IconButton(
        tooltip: tip,
        onPressed: onTap,
        icon: Icon(icon, size: 20),
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 36, minHeight: 40),
      );
}

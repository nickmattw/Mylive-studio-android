import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../models/layer.dart';
import '../state/editor_controller.dart';

class PropertiesPanel extends StatelessWidget {
  const PropertiesPanel({super.key, required this.onClose});

  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    final l = c.selected;
    return Material(
      color: AppColors.graphite,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 4, 0),
            child: Row(
              children: [
                const Expanded(
                    child: Text('Propriedades',
                        style: TextStyle(fontWeight: FontWeight.w600))),
                IconButton(
                    tooltip: 'Recolher painel',
                    onPressed: onClose,
                    icon: const Icon(Icons.chevron_right)),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: l == null
                ? Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                        'Projeto: ${c.meta.name}\n'
                        '${c.doc.width} × ${c.doc.height} px\n'
                        '${c.layers.length} camada(s)\n\n'
                        'Toque em uma camada para editar.',
                        style: const TextStyle(color: AppColors.textDim)),
                  )
                : _LayerProps(layer: l, controller: c),
          ),
        ],
      ),
    );
  }
}

class _LayerProps extends StatelessWidget {
  const _LayerProps({required this.layer, required this.controller});

  final Layer layer;
  final EditorController controller;

  double _deg(double rad) {
    final d = rad * 180 / math.pi;
    return ((d + 180) % 360 + 360) % 360 - 180;
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final l = layer;
    final isImage = l.kind == LayerKind.image;
    final enabled = !l.locked && isImage;
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Text(l.name,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        Text(isImage ? 'Imagem' : 'Pasta',
            style: const TextStyle(color: AppColors.textDim)),
        if (l.locked)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('Camada bloqueada.',
                style: TextStyle(color: AppColors.textDim)),
          ),
        if (isImage) ...[
          const SizedBox(height: 8),
          _Prop(
            label: 'Posição X',
            value: l.x,
            min: -c.doc.width.toDouble(),
            max: c.doc.width * 2.0,
            display: l.x.toStringAsFixed(0),
            enabled: enabled,
            onStart: c.beginGesture,
            onChanged: (v) => c.updateSelected((s) => s.x = v),
          ),
          _Prop(
            label: 'Posição Y',
            value: l.y,
            min: -c.doc.height.toDouble(),
            max: c.doc.height * 2.0,
            display: l.y.toStringAsFixed(0),
            enabled: enabled,
            onStart: c.beginGesture,
            onChanged: (v) => c.updateSelected((s) => s.y = v),
          ),
          _Prop(
            label: 'Escala',
            value: l.scale,
            min: 0.02,
            max: 4,
            display: '${(l.scale * 100).toStringAsFixed(0)}%',
            enabled: enabled,
            onStart: c.beginGesture,
            onChanged: (v) => c.updateSelected((s) => s.scale = v),
          ),
          _Prop(
            label: 'Rotação',
            value: _deg(l.rotation),
            min: -180,
            max: 180,
            display: '${_deg(l.rotation).toStringAsFixed(0)}°',
            enabled: enabled,
            onStart: c.beginGesture,
            onChanged: (v) =>
                c.updateSelected((s) => s.rotation = v * math.pi / 180),
          ),
          _Prop(
            label: 'Opacidade',
            value: l.opacity,
            min: 0,
            max: 1,
            display: '${(l.opacity * 100).toStringAsFixed(0)}%',
            enabled: enabled,
            onStart: c.beginGesture,
            onChanged: (v) => c.updateSelected((s) => s.opacity = v),
          ),
          const SizedBox(height: 4),
          Text(
              'Original: ${l.naturalWidth.toStringAsFixed(0)} × '
              '${l.naturalHeight.toStringAsFixed(0)} px',
              style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
        ],
      ],
    );
  }
}

class _Prop extends StatelessWidget {
  const _Prop({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.display,
    required this.enabled,
    required this.onStart,
    required this.onChanged,
  });

  final String label, display;
  final double value, min, max;
  final bool enabled;
  final VoidCallback onStart;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label)),
              Text(display, style: const TextStyle(color: AppColors.textDim)),
            ],
          ),
          Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            onChangeStart: enabled ? (_) => onStart() : null,
            onChanged: enabled ? onChanged : null,
          ),
        ],
      );
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/text_input_dialog.dart';
import '../../project/services/image_probe.dart';
import '../../project/services/project_repository.dart';
import '../canvas/editor_canvas.dart';
import '../panels/layers_panel.dart';
import '../panels/properties_panel.dart';
import '../state/editor_controller.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.projectId});

  final String projectId;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  EditorController? _c;
  Object? _error;
  bool? _leftOpen, _rightOpen;
  static const _wideBreakpoint = 900.0;
  static const _panelWidth = 280.0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final repo = context.read<ProjectRepository>();
    try {
      final meta = await repo.getProject(widget.projectId);
      final doc = await repo.loadDocument(widget.projectId);
      final c = EditorController(repository: repo, meta: meta, doc: doc);
      await c.loadImages();
      if (!mounted) {
        c.dispose();
        return;
      }
      setState(() => _c = c);
    } catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  @override
  void dispose() {
    final c = _c;
    if (c != null) c.save().whenComplete(c.dispose);
    super.dispose();
  }

  void _snack(String m) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(m)));

  Future<void> _import() async {
    final c = _c!;
    try {
      final img = await pickImage();
      if (img == null) return;
      await c.addImage(img);
    } catch (e) {
      if (mounted) _snack('Falha ao importar: $e');
    }
  }

  Future<void> _back() async {
    await _c?.save();
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _renameProject() async {
    final c = _c!;
    final n = await showTextInputDialog(context,
        title: 'Renomear projeto', initial: c.meta.name);
    if (n == null) return;
    try {
      await c.renameProject(n);
    } catch (e) {
      if (mounted) _snack(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Erro')),
        body: Center(child: Text('Erro: $_error')),
      );
    }
    if (c == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Abrindo…')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    return ChangeNotifierProvider<EditorController>.value(
      value: c,
      child: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _back();
        },
        child: LayoutBuilder(builder: (context, cons) {
          final wide = cons.maxWidth >= _wideBreakpoint;
          final left = _leftOpen ?? wide;
          final right = _rightOpen ?? wide;
          final pw = _panelWidth.clamp(0, cons.maxWidth * 0.85).toDouble();

          void toggleLeft() => setState(() {
                _leftOpen = !left;
                if (!wide && !left) _rightOpen = false;
              });
          void toggleRight() => setState(() {
                _rightOpen = !right;
                if (!wide && !right) _leftOpen = false;
              });

          final layers = LayersPanel(
              onAddImage: _import, onClose: toggleLeft);
          final props = PropertiesPanel(onClose: toggleRight);
          const canvas = EditorCanvas();

          final Widget body = wide
              ? Row(children: [
                  if (left) SizedBox(width: pw, child: layers),
                  const Expanded(child: canvas),
                  if (right) SizedBox(width: pw, child: props),
                ])
              : Stack(children: [
                  const Positioned.fill(child: canvas),
                  if (left)
                    Positioned(
                        left: 0, top: 0, bottom: 0, width: pw, child: layers),
                  if (right)
                    Positioned(
                        right: 0, top: 0, bottom: 0, width: pw, child: props),
                ]);

          return Scaffold(
            appBar: AppBar(
              leading: IconButton(
                  tooltip: 'Voltar',
                  onPressed: _back,
                  icon: const Icon(Icons.arrow_back)),
              titleSpacing: 0,
              title: Consumer<EditorController>(
                builder: (_, ctl, __) => InkWell(
                  onTap: _renameProject,
                  child: Text(ctl.meta.name,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
              ),
              actions: [_TopActions(onImport: _import)],
            ),
            body: SafeArea(top: false, bottom: false, child: body),
            bottomNavigationBar: SafeArea(
              child: _BottomBar(
                leftOpen: left,
                rightOpen: right,
                onToggleLeft: toggleLeft,
                onToggleRight: toggleRight,
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _TopActions extends StatelessWidget {
  const _TopActions({required this.onImport});
  final VoidCallback onImport;

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    Widget btn(IconData i, String tip, VoidCallback? f) => IconButton(
          tooltip: tip,
          onPressed: f,
          icon: Icon(i),
          constraints: const BoxConstraints(minWidth: 40, minHeight: 48),
          padding: EdgeInsets.zero,
        );
    return Row(mainAxisSize: MainAxisSize.min, children: [
      btn(c.dirty ? Icons.save_outlined : Icons.cloud_done_outlined,
          c.dirty ? 'Salvar (autosave ativo)' : 'Tudo salvo', c.save),
      btn(Icons.undo, 'Desfazer', c.canUndo ? c.undo : null),
      btn(Icons.redo, 'Refazer', c.canRedo ? c.redo : null),
      btn(Icons.add_photo_alternate_outlined, 'Importar imagem', onImport),
      const SizedBox(width: 4),
    ]);
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.leftOpen,
    required this.rightOpen,
    required this.onToggleLeft,
    required this.onToggleRight,
  });

  final bool leftOpen, rightOpen;
  final VoidCallback onToggleLeft, onToggleRight;

  @override
  Widget build(BuildContext context) {
    final c = context.watch<EditorController>();
    return Material(
      color: AppColors.graphite,
      child: SizedBox(
        height: 60,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 4),
          children: [
            _ToolBtn(Icons.layers_outlined, 'Camadas', leftOpen, onToggleLeft),
            _ToolBtn(Icons.near_me_outlined, 'Selecionar',
                c.tool == EditorTool.select, () => c.setTool(EditorTool.select)),
            _ToolBtn(Icons.pan_tool_outlined, 'Mover tela',
                c.tool == EditorTool.pan, () => c.setTool(EditorTool.pan)),
            _ToolBtn(Icons.fit_screen_outlined, 'Ajustar', false, c.fitToView),
            _ToolBtn(Icons.looks_one_outlined, '100%', false, c.actualSize),
            _ToolBtn(Icons.zoom_out, 'Zoom −', false, () => c.zoomBy(0.8)),
            _ToolBtn(Icons.zoom_in, 'Zoom +', false, () => c.zoomBy(1.25)),
            _ToolBtn(Icons.grid_goldenratio, 'Guias', c.showGuides,
                c.toggleGuides),
            _ToolBtn(Icons.tune, 'Propriedades', rightOpen, onToggleRight),
          ],
        ),
      ),
    );
  }
}

class _ToolBtn extends StatelessWidget {
  const _ToolBtn(this.icon, this.label, this.active, this.onTap);

  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: SizedBox(
          width: 68,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  size: 22,
                  color: active ? AppColors.purple : AppColors.text),
              const SizedBox(height: 2),
              Text(label,
                  style: TextStyle(
                      fontSize: 11,
                      color: active ? AppColors.purple : AppColors.textDim)),
            ],
          ),
        ),
      );
}

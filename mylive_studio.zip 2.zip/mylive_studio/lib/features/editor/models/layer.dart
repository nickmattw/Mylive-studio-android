enum LayerKind { image, group }

class Layer {
  Layer({
    required this.id,
    required this.name,
    required this.kind,
    this.parentId,
    this.imagePath,
    this.naturalWidth = 0,
    this.naturalHeight = 0,
    this.x = 0,
    this.y = 0,
    this.scale = 1,
    this.rotation = 0,
    this.opacity = 1,
    this.visible = true,
    this.locked = false,
  });

  final String id;
  String name;
  final LayerKind kind;
  String? parentId;

  /// Caminho relativo à pasta do projeto (ex.: assets/abc.png).
  String? imagePath;
  double naturalWidth, naturalHeight;

  /// Posição do centro da camada, em pixels da área de trabalho.
  double x, y, scale, rotation, opacity;
  bool visible, locked;

  Layer copyWith({String? id, String? name}) => Layer(
        id: id ?? this.id,
        name: name ?? this.name,
        kind: kind,
        parentId: parentId,
        imagePath: imagePath,
        naturalWidth: naturalWidth,
        naturalHeight: naturalHeight,
        x: x,
        y: y,
        scale: scale,
        rotation: rotation,
        opacity: opacity,
        visible: visible,
        locked: locked,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'kind': kind.name,
        'parentId': parentId,
        'imagePath': imagePath,
        'naturalWidth': naturalWidth,
        'naturalHeight': naturalHeight,
        'x': x,
        'y': y,
        'scale': scale,
        'rotation': rotation,
        'opacity': opacity,
        'visible': visible,
        'locked': locked,
      };

  factory Layer.fromJson(Map<String, dynamic> j) => Layer(
        id: j['id'] as String,
        name: j['name'] as String,
        kind: LayerKind.values.byName(j['kind'] as String),
        parentId: j['parentId'] as String?,
        imagePath: j['imagePath'] as String?,
        naturalWidth: (j['naturalWidth'] as num? ?? 0).toDouble(),
        naturalHeight: (j['naturalHeight'] as num? ?? 0).toDouble(),
        x: (j['x'] as num).toDouble(),
        y: (j['y'] as num).toDouble(),
        scale: (j['scale'] as num).toDouble(),
        rotation: (j['rotation'] as num).toDouble(),
        opacity: (j['opacity'] as num).toDouble(),
        visible: j['visible'] as bool,
        locked: j['locked'] as bool,
      );
}

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../models/layer.dart';
import '../state/editor_controller.dart';

class CanvasPainter extends CustomPainter {
  CanvasPainter(this.c) : super(repaint: c);

  final EditorController c;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = AppColors.black);
    final doc = c.doc;
    final docRect = Rect.fromLTWH(
        c.pan.dx, c.pan.dy, doc.width * c.zoom, doc.height * c.zoom);
    final vis = docRect.intersect(Offset.zero & size);
    if (vis.width > 0 && vis.height > 0) _checker(canvas, docRect, vis);

    // Camadas (do fundo para o topo)
    canvas.save();
    canvas.translate(c.pan.dx, c.pan.dy);
    canvas.scale(c.zoom);
    for (final l in c.layers) {
      if (l.kind != LayerKind.image || !c.effectivelyVisible(l)) continue;
      final img = c.images[l.imagePath];
      if (img == null) continue;
      canvas.save();
      canvas.translate(l.x, l.y);
      canvas.rotate(l.rotation);
      canvas.scale(l.scale);
      canvas.drawImage(
        img,
        Offset(-l.naturalWidth / 2, -l.naturalHeight / 2),
        Paint()
          ..filterQuality = FilterQuality.medium
          ..color = Color.fromRGBO(0, 0, 0, l.opacity.clamp(0.0, 1.0)),
      );
      canvas.restore();
    }
    canvas.restore();

    // Borda e guias
    canvas.drawRect(
        docRect,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = AppColors.textDim);
    if (c.showGuides) {
      final g = Paint()
        ..strokeWidth = 1
        ..color = AppColors.violetBlue.withAlpha(150);
      canvas.drawLine(Offset(docRect.center.dx, docRect.top),
          Offset(docRect.center.dx, docRect.bottom), g);
      canvas.drawLine(Offset(docRect.left, docRect.center.dy),
          Offset(docRect.right, docRect.center.dy), g);
    }

    // Seleção
    final sel = c.selected;
    if (sel != null && sel.kind == LayerKind.image) {
      final pts = c.cornersDoc(sel).map(c.docToScreen).toList();
      final path = Path()..addPolygon(pts, true);
      canvas.drawPath(
          path,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2
            ..color = sel.locked ? AppColors.textDim : AppColors.purple);
      if (!sel.locked) {
        canvas.drawCircle(pts[2], 11, Paint()..color = AppColors.purple);
        canvas.drawCircle(
            pts[2],
            11,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 2
              ..color = Colors.white);
      }
    }
  }

  void _checker(Canvas canvas, Rect docRect, Rect vis) {
    const tile = 12.0;
    canvas.save();
    canvas.clipRect(vis);
    canvas.drawRect(vis, Paint()..color = const Color(0xFF3A3A46));
    final dark = Paint()..color = const Color(0xFF2C2C36);
    final c0 = ((vis.left - docRect.left) / tile).floor();
    final c1 = ((vis.right - docRect.left) / tile).ceil();
    final r0 = ((vis.top - docRect.top) / tile).floor();
    final r1 = ((vis.bottom - docRect.top) / tile).ceil();
    for (var r = r0; r < r1; r++) {
      for (var col = c0; col < c1; col++) {
        if ((r + col).isOdd) {
          canvas.drawRect(
              Rect.fromLTWH(docRect.left + col * tile,
                  docRect.top + r * tile, tile, tile),
              dark);
        }
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(CanvasPainter old) => true;
}

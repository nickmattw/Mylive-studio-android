import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/layer.dart';
import '../state/editor_controller.dart';
import 'canvas_painter.dart';

enum _Mode { none, pan, drag, handle, pinch }

/// Canvas interativo (toque, mouse e roda). Gestos:
/// 1 dedo/mouse: arrastar camada ou mover a área; toque: selecionar;
/// alça roxa: escala + rotação; 2 dedos: zoom e movimentação; roda: zoom.
class EditorCanvas extends StatefulWidget {
  const EditorCanvas({super.key});

  @override
  State<EditorCanvas> createState() => _EditorCanvasState();
}

class _EditorCanvasState extends State<EditorCanvas> {
  static const _slop = 6.0;
  static const _handleRadius = 30.0;

  final Map<int, Offset> _pointers = {};
  _Mode _mode = _Mode.none;
  Offset _downPos = Offset.zero;
  bool _moved = false;
  bool _gestureStarted = false;
  bool _tapDeselect = false;

  double _pinchDist0 = 1, _zoom0 = 1;
  Offset _pinchMid0 = Offset.zero, _pan0 = Offset.zero;

  double _hScale0 = 1, _hRot0 = 0, _hDist0 = 1, _hAng0 = 0;
  Offset _hCenter = Offset.zero;

  EditorController get c => context.read<EditorController>();

  Offset? _handleScreenPos() {
    final l = c.selected;
    if (l == null || l.locked || l.kind != LayerKind.image) return null;
    return c.docToScreen(c.cornersDoc(l)[2]);
  }

  void _startPinch() {
    final pts = _pointers.values.take(2).toList();
    _pinchDist0 = (pts[0] - pts[1]).distance.clamp(1.0, 1e9).toDouble();
    _pinchMid0 = (pts[0] + pts[1]) / 2;
    _zoom0 = c.zoom;
    _pan0 = c.pan;
    _mode = _Mode.pinch;
  }

  void _down(PointerDownEvent e) {
    _pointers[e.pointer] = e.localPosition;
    if (_pointers.length == 2) {
      _startPinch();
      return;
    }
    if (_pointers.length > 2) return;

    final ctl = c;
    final pos = e.localPosition;
    _downPos = pos;
    _moved = false;
    _gestureStarted = false;
    _tapDeselect = false;

    if (ctl.tool == EditorTool.pan) {
      _mode = _Mode.pan;
      return;
    }
    final h = _handleScreenPos();
    if (h != null && (pos - h).distance <= _handleRadius) {
      final l = ctl.selected!;
      _hCenter = ctl.docToScreen(Offset(l.x, l.y));
      final v0 = h - _hCenter;
      _hDist0 = v0.distance;
      _hAng0 = v0.direction;
      _hScale0 = l.scale;
      _hRot0 = l.rotation;
      _mode = _Mode.handle;
      return;
    }
    final hit = ctl.hitTest(ctl.screenToDoc(pos));
    if (hit != null) {
      if (ctl.selectedId != hit.id) ctl.select(hit.id);
      _mode = _Mode.drag;
    } else {
      _mode = _Mode.pan;
      _tapDeselect = true;
    }
  }

  void _move(PointerMoveEvent e) {
    final prev = _pointers[e.pointer];
    if (prev == null) return;
    final pos = e.localPosition;
    _pointers[e.pointer] = pos;
    final ctl = c;

    if (_mode == _Mode.pinch && _pointers.length >= 2) {
      final pts = _pointers.values.take(2).toList();
      final dist = (pts[0] - pts[1]).distance.clamp(1.0, 1e9).toDouble();
      final mid = (pts[0] + pts[1]) / 2;
      final z = (_zoom0 * dist / _pinchDist0).clamp(0.02, 16.0).toDouble();
      final docPoint = (_pinchMid0 - _pan0) / _zoom0;
      ctl.setViewport(z, mid - docPoint * z);
      return;
    }
    if (_pointers.length != 1) return;
    if (!_moved && (pos - _downPos).distance < _slop) return;
    _moved = true;
    final delta = pos - prev;

    switch (_mode) {
      case _Mode.pan:
        ctl.panBy(delta);
      case _Mode.drag:
        if (!_gestureStarted) {
          ctl.beginGesture();
          _gestureStarted = true;
        }
        ctl.moveSelectedBy(delta.dx / ctl.zoom, delta.dy / ctl.zoom);
      case _Mode.handle:
        if (_hDist0 < 1) return;
        if (!_gestureStarted) {
          ctl.beginGesture();
          _gestureStarted = true;
        }
        final v = pos - _hCenter;
        ctl.setSelectedTransform(
          scale: (_hScale0 * v.distance / _hDist0).clamp(0.02, 20.0).toDouble(),
          rotation: _hRot0 + (v.direction - _hAng0),
        );
      case _Mode.pinch:
      case _Mode.none:
        break;
    }
  }

  void _up(PointerEvent e) {
    if (!_pointers.containsKey(e.pointer)) return;
    if (_pointers.length == 1 && !_moved && _tapDeselect &&
        e is PointerUpEvent) {
      c.select(null);
    }
    _pointers.remove(e.pointer);
    if (_pointers.isEmpty) {
      _mode = _Mode.none;
    } else if (_mode == _Mode.pinch && _pointers.length < 2) {
      _mode = _Mode.none;
    }
  }

  void _signal(PointerSignalEvent s) {
    if (s is PointerScrollEvent) {
      c.zoomAt(s.localPosition, s.scrollDelta.dy > 0 ? 0.9 : 1.1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ctl = context.read<EditorController>();
    return LayoutBuilder(builder: (context, cons) {
      final size = Size(cons.maxWidth, cons.maxHeight);
      WidgetsBinding.instance
          .addPostFrameCallback((_) => ctl.setViewSize(size));
      return Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: _down,
        onPointerMove: _move,
        onPointerUp: _up,
        onPointerCancel: _up,
        onPointerSignal: _signal,
        child: ClipRect(
          child: CustomPaint(painter: CanvasPainter(ctl), size: Size.infinite),
        ),
      );
    });
  }
}

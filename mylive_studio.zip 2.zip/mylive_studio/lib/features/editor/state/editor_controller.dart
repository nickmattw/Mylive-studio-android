import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../../project/models/project_document.dart';
import '../../project/models/project_meta.dart';
import '../../project/services/project_repository.dart';
import '../models/layer.dart';

enum EditorTool { select, pan }

/// Estado do editor: documento, seleção, viewport, histórico e autosave.
/// Desfazer/refazer usa snapshots JSON da lista de camadas (até 100).
class EditorController extends ChangeNotifier {
  EditorController({
    required this.repository,
    required this.meta,
    required this.doc,
  });

  final ProjectRepository repository;
  ProjectMeta meta;
  final ProjectDocument doc;

  static const _uuid = Uuid();
  static const _maxHistory = 100;
  static const autosaveDelay = Duration(seconds: 2);

  final Map<String, ui.Image> images = {};
  String? selectedId;
  EditorTool tool = EditorTool.select;
  bool showGuides = true;

  double zoom = 1;
  ui.Offset pan = ui.Offset.zero;
  ui.Size viewSize = ui.Size.zero;
  bool _fitted = false;

  final List<String> _undo = [];
  final List<String> _redo = [];
  bool dirty = false;
  bool saving = false;
  String? lastError;
  int _version = 0;
  Timer? _timer;
  bool _disposed = false;

  List<Layer> get layers => doc.layers;
  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;
  Layer? get selected => layerById(selectedId);

  Layer? layerById(String? id) {
    if (id == null) return null;
    for (final l in layers) {
      if (l.id == id) return l;
    }
    return null;
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  // ---------------------------------------------------------------- imagens

  Future<void> loadImages() async {
    for (final l in layers) {
      await _ensureImage(l.imagePath);
    }
    _notify();
  }

  Future<void> _ensureImage(String? path) async {
    if (path == null || images.containsKey(path)) return;
    try {
      final bytes = await repository.loadAsset(meta.id, path);
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      images[path] = frame.image;
      codec.dispose();
    } catch (_) {
      lastError = 'Imagem ausente ou inválida: $path';
    }
  }

  Future<void> addImage(ImportedImage img) async {
    final rel = await repository.importImage(meta.id, img.name, img.bytes);
    await _ensureImage(rel);
    final fit = math.min(
        math.min(doc.width / img.width, doc.height / img.height), 1.0);
    final sel = selected;
    insertLayer(Layer(
      id: _uuid.v4(),
      name: ProjectRepository.baseName(img.name),
      kind: LayerKind.image,
      parentId: sel != null && sel.kind == LayerKind.group ? sel.id : null,
      imagePath: rel,
      naturalWidth: img.width.toDouble(),
      naturalHeight: img.height.toDouble(),
      x: doc.width / 2,
      y: doc.height / 2,
      scale: fit,
    ));
  }

  // ---------------------------------------------------------------- histórico

  String _snapshot() =>
      jsonEncode(layers.map((l) => l.toJson()).toList());

  void _pushUndo() {
    _undo.add(_snapshot());
    if (_undo.length > _maxHistory) _undo.removeAt(0);
    _redo.clear();
  }

  void _changed() {
    dirty = true;
    _version++;
    _schedule();
    _notify();
  }

  void _restore(String snap) {
    final list = (jsonDecode(snap) as List)
        .map((e) => Layer.fromJson(e as Map<String, dynamic>))
        .toList();
    layers
      ..clear()
      ..addAll(list);
    if (layerById(selectedId) == null) selectedId = null;
    _changed();
  }

  void undo() {
    if (_undo.isEmpty) return;
    _redo.add(_snapshot());
    _restore(_undo.removeLast());
  }

  void redo() {
    if (_redo.isEmpty) return;
    _undo.add(_snapshot());
    _restore(_redo.removeLast());
  }

  /// Chamar UMA vez antes de um gesto contínuo (arrastar, slider).
  void beginGesture() => _pushUndo();

  // ---------------------------------------------------------------- camadas

  void insertLayer(Layer layer, {int? index}) {
    _pushUndo();
    if (index == null) {
      layers.add(layer);
    } else {
      layers.insert(index, layer);
    }
    selectedId = layer.id;
    _changed();
  }

  void addGroup([String name = 'Pasta']) {
    final sel = selected;
    insertLayer(Layer(
      id: _uuid.v4(),
      name: name,
      kind: LayerKind.group,
      parentId: sel?.kind == LayerKind.group ? sel!.id : sel?.parentId,
    ));
  }

  void select(String? id) {
    selectedId = id;
    _notify();
  }

  void deleteLayer(String id) {
    final l = layerById(id);
    if (l == null) return;
    _pushUndo();
    for (final c in layers) {
      if (c.parentId == id) c.parentId = l.parentId;
    }
    layers.remove(l);
    if (selectedId == id) selectedId = null;
    _changed();
  }

  void rename(String id, String name) {
    final l = layerById(id);
    final n = name.trim();
    if (l == null || n.isEmpty) return;
    _pushUndo();
    l.name = n;
    _changed();
  }

  void duplicate(String id) {
    final l = layerById(id);
    if (l == null) return;
    final copy = l.copyWith(id: _uuid.v4(), name: '${l.name} cópia')
      ..x = l.x + 24
      ..y = l.y + 24;
    insertLayer(copy, index: layers.indexOf(l) + 1);
  }

  void toggleVisible(String id) {
    final l = layerById(id);
    if (l == null) return;
    _pushUndo();
    l.visible = !l.visible;
    _changed();
  }

  void toggleLock(String id) {
    final l = layerById(id);
    if (l == null) return;
    _pushUndo();
    l.locked = !l.locked;
    _changed();
  }

  /// Reordena na lista plana (índices do fundo para o topo).
  void moveLayer(int oldIndex, int newIndex) {
    if (oldIndex == newIndex ||
        oldIndex < 0 ||
        newIndex < 0 ||
        oldIndex >= layers.length ||
        newIndex >= layers.length) {
      return;
    }
    _pushUndo();
    final l = layers.removeAt(oldIndex);
    layers.insert(newIndex, l);
    _changed();
  }

  bool isDescendant(String candidateId, String ancestorId) {
    var cur = layerById(candidateId);
    for (var i = 0; i < 64 && cur != null; i++) {
      if (cur.parentId == ancestorId) return true;
      cur = layerById(cur.parentId);
    }
    return false;
  }

  /// groupId == null move para a raiz. Impede ciclos.
  bool moveToGroup(String id, String? groupId) {
    final l = layerById(id);
    if (l == null) return false;
    if (groupId != null) {
      final g = layerById(groupId);
      if (g == null || g.kind != LayerKind.group) return false;
      if (groupId == id || isDescendant(groupId, id)) return false;
    }
    _pushUndo();
    l.parentId = groupId;
    _changed();
    return true;
  }

  /// Cria uma pasta nova contendo a camada [id].
  void groupLayer(String id) {
    final l = layerById(id);
    if (l == null) return;
    _pushUndo();
    final g = Layer(
        id: _uuid.v4(), name: 'Pasta', kind: LayerKind.group, parentId: l.parentId);
    layers.insert(layers.indexOf(l), g);
    l.parentId = g.id;
    _changed();
  }

  int depthOf(Layer l) {
    var d = 0;
    var cur = layerById(l.parentId);
    while (cur != null && d < 64) {
      d++;
      cur = layerById(cur.parentId);
    }
    return d;
  }

  bool effectivelyVisible(Layer l) {
    Layer? cur = l;
    for (var i = 0; i < 64 && cur != null; i++) {
      if (!cur.visible) return false;
      cur = layerById(cur.parentId);
    }
    return true;
  }

  // ---------------------------------------------------------- transformações

  void moveSelectedBy(double dx, double dy) {
    final l = selected;
    if (l == null || l.locked) return;
    l.x += dx;
    l.y += dy;
    _changed();
  }

  void setSelectedTransform({double? scale, double? rotation}) {
    final l = selected;
    if (l == null || l.locked) return;
    if (scale != null) l.scale = scale;
    if (rotation != null) l.rotation = rotation;
    _changed();
  }

  /// Usar após [beginGesture] (sliders).
  void updateSelected(void Function(Layer) f) {
    final l = selected;
    if (l == null || l.locked) return;
    f(l);
    _changed();
  }

  // ---------------------------------------------------------------- geometria

  ui.Offset docToScreen(ui.Offset p) => p * zoom + pan;
  ui.Offset screenToDoc(ui.Offset s) => (s - pan) / zoom;

  ui.Offset _rot(ui.Offset v, double a) {
    final c = math.cos(a), s = math.sin(a);
    return ui.Offset(v.dx * c - v.dy * s, v.dx * s + v.dy * c);
  }

  /// Cantos (sup-esq, sup-dir, inf-dir, inf-esq) em coordenadas do documento.
  List<ui.Offset> cornersDoc(Layer l) {
    final hw = l.naturalWidth * l.scale / 2;
    final hh = l.naturalHeight * l.scale / 2;
    final c = ui.Offset(l.x, l.y);
    return [
      ui.Offset(-hw, -hh),
      ui.Offset(hw, -hh),
      ui.Offset(hw, hh),
      ui.Offset(-hw, hh),
    ].map((p) => _rot(p, l.rotation) + c).toList();
  }

  /// Camada selecionável mais ao topo sob o ponto (coordenadas do documento).
  Layer? hitTest(ui.Offset docPoint) {
    for (var i = layers.length - 1; i >= 0; i--) {
      final l = layers[i];
      if (l.kind != LayerKind.image || l.locked || !effectivelyVisible(l)) {
        continue;
      }
      final local =
          _rot(docPoint - ui.Offset(l.x, l.y), -l.rotation) / l.scale;
      if (local.dx.abs() <= l.naturalWidth / 2 &&
          local.dy.abs() <= l.naturalHeight / 2) {
        return l;
      }
    }
    return null;
  }

  // ---------------------------------------------------------------- viewport

  void setViewSize(ui.Size s) {
    if (s == viewSize) return;
    viewSize = s;
    if (!_fitted && s.width > 0 && s.height > 0) {
      _fitted = true;
      fitToView();
      return;
    }
    _notify();
  }

  void fitToView() {
    if (viewSize.width <= 0 || viewSize.height <= 0) return;
    const m = 24.0;
    final z = math.min((viewSize.width - 2 * m) / doc.width,
        (viewSize.height - 2 * m) / doc.height);
    zoom = z.clamp(0.02, 16.0).toDouble();
    _center();
  }

  void actualSize() {
    zoom = 1;
    _center();
  }

  void _center() {
    pan = ui.Offset((viewSize.width - doc.width * zoom) / 2,
        (viewSize.height - doc.height * zoom) / 2);
    _notify();
  }

  void setViewport(double z, ui.Offset p) {
    zoom = z.clamp(0.02, 16.0).toDouble();
    pan = p;
    _notify();
  }

  void zoomAt(ui.Offset focal, double factor) {
    final nz = (zoom * factor).clamp(0.02, 16.0).toDouble();
    pan = focal - (focal - pan) * (nz / zoom);
    zoom = nz;
    _notify();
  }

  void zoomBy(double factor) => zoomAt(
      ui.Offset(viewSize.width / 2, viewSize.height / 2), factor);

  void panBy(ui.Offset d) {
    pan += d;
    _notify();
  }

  void setTool(EditorTool t) {
    tool = t;
    _notify();
  }

  void toggleGuides() {
    showGuides = !showGuides;
    _notify();
  }

  // ---------------------------------------------------------------- salvar

  void _schedule() {
    _timer?.cancel();
    _timer = Timer(autosaveDelay, save);
  }

  Future<void> save() async {
    _timer?.cancel();
    if (!dirty || saving) return;
    saving = true;
    final v = _version;
    _notify();
    try {
      await repository.saveDocument(meta.id, doc);
      if (_version == v) dirty = false;
      lastError = null;
    } catch (e) {
      lastError = e.toString();
    }
    saving = false;
    _notify();
    if (dirty && !_disposed) _schedule();
  }

  Future<void> renameProject(String name) async {
    await repository.renameProject(meta.id, name);
    meta = meta.copyWith(name: name.trim());
    _notify();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    for (final i in images.values) {
      i.dispose();
    }
    images.clear();
    super.dispose();
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../editor/ui/editor_screen.dart';
import '../../home/state/home_controller.dart';
import '../services/image_probe.dart';
import '../services/project_repository.dart';

class CreateProjectScreen extends StatefulWidget {
  const CreateProjectScreen({super.key});

  @override
  State<CreateProjectScreen> createState() => _CreateProjectScreenState();
}

class _Ratio {
  const _Ratio(this.label, this.w, this.h);
  final String label;
  final int w, h;
}

class _CreateProjectScreenState extends State<CreateProjectScreen> {
  static const _ratios = [
    _Ratio('1:1', 1, 1),
    _Ratio('16:9', 16, 9),
    _Ratio('9:16', 9, 16),
    _Ratio('4:3', 4, 3),
    _Ratio('3:4', 3, 4),
  ];
  static const _sizes = [1024, 2048, 4096];

  final _name = TextEditingController(text: 'Novo projeto');
  _Ratio _ratio = _ratios.first;
  int _longSide = 2048;
  ImportedImage? _image;
  bool _withImage = false;
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  (int, int) get _dims {
    final longer = _ratio.w >= _ratio.h ? _ratio.w : _ratio.h;
    final k = _longSide / longer;
    return ((_ratio.w * k).round(), (_ratio.h * k).round());
  }

  void _snack(String m) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(m)));

  Future<void> _pickImage() async {
    try {
      final img = await pickImage();
      if (img == null || !mounted) return;
      setState(() => _image = img);
    } catch (_) {
      if (mounted) _snack('Não foi possível ler a imagem.');
    }
  }

  Future<void> _create() async {
    if (_withImage && _image == null) {
      _snack('Escolha uma imagem ou selecione projeto vazio.');
      return;
    }
    final home = context.read<HomeController>();
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      final (w, h) = _dims;
      final meta = await home.create(
        name: _name.text,
        width: w,
        height: h,
        initialImage: _withImage ? _image : null,
      );
      nav.pushReplacement(MaterialPageRoute(
          builder: (_) => EditorScreen(projectId: meta.id)));
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        _snack(e.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final (w, h) = _dims;
    return Scaffold(
      appBar: AppBar(title: const Text('Novo projeto')),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                TextField(
                  controller: _name,
                  maxLength: 80,
                  decoration: const InputDecoration(
                      labelText: 'Nome do projeto',
                      border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                const Text('Proporção'),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  for (final r in _ratios)
                    ChoiceChip(
                      label: Text(r.label),
                      selected: r == _ratio,
                      onSelected: (_) => setState(() => _ratio = r),
                    ),
                ]),
                const SizedBox(height: 16),
                const Text('Resolução (lado maior)'),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  for (final s in _sizes)
                    ChoiceChip(
                      label: Text('$s px'),
                      selected: s == _longSide,
                      onSelected: (_) => setState(() => _longSide = s),
                    ),
                ]),
                const SizedBox(height: 8),
                Text('Área de trabalho: $w × $h px',
                    style: const TextStyle(color: AppColors.textDim)),
                const SizedBox(height: 20),
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: false, label: Text('Projeto vazio')),
                    ButtonSegment(value: true, label: Text('Com imagem')),
                  ],
                  selected: {_withImage},
                  onSelectionChanged: (s) =>
                      setState(() => _withImage = s.first),
                ),
                if (_withImage) ...[
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _pickImage,
                    icon: const Icon(Icons.image_outlined),
                    label: Text(_image == null
                        ? 'Escolher PNG / JPG'
                        : 'Trocar imagem'),
                  ),
                  if (_image != null) ...[
                    const SizedBox(height: 8),
                    Text('${_image!.width} × ${_image!.height} px',
                        style: const TextStyle(color: AppColors.textDim)),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 140,
                      child: Image.memory(_image!.bytes, fit: BoxFit.contain),
                    ),
                  ],
                ],
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _busy ? null : _create,
                  child: _busy
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Criar projeto'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

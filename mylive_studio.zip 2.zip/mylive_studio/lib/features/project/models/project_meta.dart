/// Linha do índice SQLite: dados leves para listar projetos.
class ProjectMeta {
  const ProjectMeta({
    required this.id,
    required this.name,
    required this.width,
    required this.height,
    required this.createdAt,
    required this.modifiedAt,
    this.thumbnailPath,
  });

  final String id;
  final String name;
  final int width, height;
  final DateTime createdAt, modifiedAt;

  /// Relativo à pasta do projeto.
  final String? thumbnailPath;

  ProjectMeta copyWith({String? name, DateTime? modifiedAt}) => ProjectMeta(
        id: id,
        name: name ?? this.name,
        width: width,
        height: height,
        createdAt: createdAt,
        modifiedAt: modifiedAt ?? this.modifiedAt,
        thumbnailPath: thumbnailPath,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'width': width,
        'height': height,
        'created_at': createdAt.millisecondsSinceEpoch,
        'modified_at': modifiedAt.millisecondsSinceEpoch,
        'thumbnail_path': thumbnailPath,
      };

  factory ProjectMeta.fromMap(Map<String, Object?> m) => ProjectMeta(
        id: m['id'] as String,
        name: m['name'] as String,
        width: m['width'] as int,
        height: m['height'] as int,
        createdAt: DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int),
        modifiedAt:
            DateTime.fromMillisecondsSinceEpoch(m['modified_at'] as int),
        thumbnailPath: m['thumbnail_path'] as String?,
      );
}

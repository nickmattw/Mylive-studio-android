import '../../editor/models/layer.dart';

/// Conteúdo completo de um projeto (salvo em project.json).
class ProjectDocument {
  ProjectDocument({
    required this.width,
    required this.height,
    List<Layer>? layers,
    this.formatVersion = currentFormatVersion,
  }) : layers = layers ?? [];

  static const int currentFormatVersion = 1;

  final int width, height;
  final int formatVersion;

  /// Ordem do fundo para o topo.
  final List<Layer> layers;

  Map<String, dynamic> toJson() => {
        'formatVersion': formatVersion,
        'width': width,
        'height': height,
        'layers': layers.map((l) => l.toJson()).toList(),
      };

  factory ProjectDocument.fromJson(Map<String, dynamic> j) => ProjectDocument(
        formatVersion: j['formatVersion'] as int? ?? 1,
        width: j['width'] as int,
        height: j['height'] as int,
        layers: (j['layers'] as List)
            .map((e) => Layer.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';

import 'project_repository.dart';

/// Decodifica apenas para descobrir largura/altura (valida a imagem).
Future<ImportedImage> probeImage(String name, Uint8List bytes) async {
  final codec = await ui.instantiateImageCodec(bytes);
  try {
    final frame = await codec.getNextFrame();
    final img = frame.image;
    final result = ImportedImage(
        name: name, bytes: bytes, width: img.width, height: img.height);
    img.dispose();
    return result;
  } finally {
    codec.dispose();
  }
}

/// Seletor de imagem multiplataforma (Web e Android). Retorna null se cancelado.
Future<ImportedImage?> pickImage() async {
  final r = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: const ['png', 'jpg', 'jpeg'],
    withData: true,
  );
  if (r == null || r.files.isEmpty) return null;
  final f = r.files.single;
  final bytes = f.bytes;
  if (bytes == null) throw ProjectException('Não foi possível ler o arquivo.');
  return probeImage(f.name, bytes);
}

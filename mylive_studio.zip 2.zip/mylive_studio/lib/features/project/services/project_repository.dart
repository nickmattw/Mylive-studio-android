import 'dart:convert';
import 'dart:typed_data';

import 'package:uuid/uuid.dart';

import '../../../core/storage/project_store.dart';
import '../../editor/models/layer.dart';
import '../models/project_document.dart';
import '../models/project_meta.dart';

class ProjectException implements Exception {
  ProjectException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Imagem escolhida pelo usuário (bytes originais + dimensões decodificadas).
class ImportedImage {
  const ImportedImage({
    required this.name,
    required this.bytes,
    required this.width,
    required this.height,
  });
  final String name;
  final Uint8List bytes;
  final int width, height;
}

/// Regras de negócio dos projetos, independentes de plataforma.
/// O armazenamento real é delegado a um [ProjectStore].
class ProjectRepository {
  ProjectRepository(this.store);

  final ProjectStore store;

  static const _allowedExt = {'png', 'jpg', 'jpeg'};
  static const _uuid = Uuid();

  static String extensionOf(String fileName) {
    final i = fileName.lastIndexOf('.');
    return i < 0 ? '' : fileName.substring(i + 1).toLowerCase();
  }

  static String baseName(String fileName) {
    final slash = fileName.lastIndexOf(RegExp(r'[\\/]'));
    final n = slash < 0 ? fileName : fileName.substring(slash + 1);
    final i = n.lastIndexOf('.');
    return i <= 0 ? n : n.substring(0, i);
  }

  Future<List<ProjectMeta>> listProjects() => store.listProjects();

  Future<ProjectMeta> getProject(String id) async {
    final m = await store.getProject(id);
    if (m == null) throw ProjectException('Projeto não encontrado.');
    return m;
  }

  Future<ProjectMeta> createProject({
    required String name,
    required int width,
    required int height,
    ImportedImage? initialImage,
  }) async {
    final cleanName = _validName(name);
    if (width < 1 || height < 1 || width > 16384 || height > 16384) {
      throw ProjectException('Resolução inválida.');
    }
    final id = _uuid.v4();
    try {
      final doc = ProjectDocument(width: width, height: height);
      String? thumb;
      if (initialImage != null) {
        final rel = await importImage(id, initialImage.name, initialImage.bytes);
        final fit = [
          width / initialImage.width,
          height / initialImage.height,
          1.0
        ].reduce((a, b) => a < b ? a : b);
        doc.layers.add(Layer(
          id: _uuid.v4(),
          name: baseName(initialImage.name),
          kind: LayerKind.image,
          imagePath: rel,
          naturalWidth: initialImage.width.toDouble(),
          naturalHeight: initialImage.height.toDouble(),
          x: width / 2,
          y: height / 2,
          scale: fit,
        ));
        thumb = rel;
      }
      await store.writeDocument(id, jsonEncode(doc.toJson()));
      final now = DateTime.now();
      final meta = ProjectMeta(
        id: id,
        name: cleanName,
        width: width,
        height: height,
        createdAt: now,
        modifiedAt: now,
        thumbnailPath: thumb,
      );
      await store.upsertProject(meta);
      return meta;
    } catch (_) {
      try {
        await store.deleteProject(id);
      } catch (_) {}
      rethrow;
    }
  }

  /// Guarda os bytes ORIGINAIS (PNG/JPG, sem recompressão: preserva a
  /// transparência). Retorna o caminho relativo (assets/<uuid>.<ext>).
  Future<String> importImage(
      String projectId, String fileName, Uint8List bytes) async {
    final ext = extensionOf(fileName);
    if (!_allowedExt.contains(ext)) {
      throw ProjectException('Formato não suportado. Use PNG, JPG ou JPEG.');
    }
    if (bytes.isEmpty) throw ProjectException('Arquivo de imagem vazio.');
    final rel = 'assets/${_uuid.v4()}.$ext';
    await store.putAsset(projectId, rel, bytes);
    return rel;
  }

  Future<Uint8List> loadAsset(String projectId, String relativePath) async {
    final b = await store.getAsset(projectId, relativePath);
    if (b == null) throw ProjectException('Imagem não encontrada.');
    return b;
  }

  /// Lê o documento; se o principal estiver corrompido, usa o backup.
  Future<ProjectDocument> loadDocument(String id) async {
    for (final raw in await store.readDocumentCandidates(id)) {
      try {
        return ProjectDocument.fromJson(
            jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {
        continue;
      }
    }
    throw ProjectException('Não foi possível carregar o projeto.');
  }

  Future<void> saveDocument(String id, ProjectDocument doc) async {
    final meta = await getProject(id);
    await store.writeDocument(id, jsonEncode(doc.toJson()));
    await store.upsertProject(meta.copyWith(modifiedAt: DateTime.now()));
  }

  Future<void> renameProject(String id, String newName) async {
    final meta = await getProject(id);
    await store.upsertProject(
        meta.copyWith(name: _validName(newName), modifiedAt: DateTime.now()));
  }

  Future<void> deleteProject(String id) => store.deleteProject(id);

  String _validName(String name) {
    final n = name.trim();
    if (n.isEmpty) throw ProjectException('O nome não pode ficar vazio.');
    if (n.length > 80) throw ProjectException('Nome muito longo (máx. 80).');
    return n;
  }
}

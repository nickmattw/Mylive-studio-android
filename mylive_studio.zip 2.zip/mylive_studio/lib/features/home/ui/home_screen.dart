import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/date_format.dart';
import '../../../core/widgets/app_logo.dart';
import '../../../core/widgets/checkerboard.dart';
import '../../../core/widgets/text_input_dialog.dart';
import '../../editor/ui/editor_screen.dart';
import '../../project/models/project_meta.dart';
import '../../project/services/project_repository.dart';
import '../../project/ui/create_project_screen.dart';
import '../state/home_controller.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _snack(BuildContext context, String msg) =>
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _openProject(BuildContext context, ProjectMeta m) async {
    final c = context.read<HomeController>();
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => EditorScreen(projectId: m.id)));
    await c.load();
  }

  Future<void> _newProject(BuildContext context) async {
    final c = context.read<HomeController>();
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => const CreateProjectScreen()));
    await c.load();
  }

  Future<void> _pickProject(BuildContext context) async {
    final c = context.read<HomeController>();
    if (c.projects.isEmpty) {
      _snack(context, 'Nenhum projeto para abrir. Crie um novo projeto.');
      return;
    }
    final chosen = await showModalBottomSheet<ProjectMeta>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            for (final m in c.projects)
              ListTile(
                leading: const Icon(Icons.folder_open_outlined),
                title: Text(m.name),
                subtitle: Text(formatDateTime(m.modifiedAt)),
                onTap: () => Navigator.pop(ctx, m),
              ),
          ],
        ),
      ),
    );
    if (chosen != null && context.mounted) {
      await _openProject(context, chosen);
    }
  }

  Future<void> _rename(BuildContext context, ProjectMeta m) async {
    final c = context.read<HomeController>();
    final name = await showTextInputDialog(context,
        title: 'Renomear projeto', initial: m.name);
    if (name == null) return;
    try {
      await c.rename(m.id, name);
    } catch (e) {
      if (context.mounted) _snack(context, e.toString());
    }
  }

  Future<void> _delete(BuildContext context, ProjectMeta m) async {
    final c = context.read<HomeController>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Excluir projeto?'),
        content: Text('"${m.name}" e suas imagens serão apagados.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Excluir')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await c.delete(m.id);
    } catch (e) {
      if (context.mounted) _snack(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<HomeController>();
    final repo = context.read<ProjectRepository>();
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 8),
              sliver: SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const AppLogo(),
                    const SizedBox(height: 20),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        FilledButton.icon(
                          onPressed: () => _newProject(context),
                          icon: const Icon(Icons.add),
                          label: const Text('Novo Projeto'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => _pickProject(context),
                          style: OutlinedButton.styleFrom(
                              minimumSize: const Size(48, 48),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12))),
                          icon: const Icon(Icons.folder_open_outlined),
                          label: const Text('Abrir Projeto'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    const Text('Projetos recentes',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
            if (c.error != null)
              SliverToBoxAdapter(
                  child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text('Erro: ${c.error}'),
              ))
            else if (c.loading && c.projects.isEmpty)
              const SliverToBoxAdapter(
                  child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(child: CircularProgressIndicator())))
            else if (c.projects.isEmpty)
              const SliverToBoxAdapter(
                  child: Padding(
                padding: EdgeInsets.all(20),
                child: Text('Nenhum projeto ainda. Toque em Novo Projeto.',
                    style: TextStyle(color: AppColors.textDim)),
              ))
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 240,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 14,
                    childAspectRatio: 0.9,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (ctx, i) {
                      final m = c.projects[i];
                      return _ProjectCard(
                        meta: m,
                        repository: repo,
                        onOpen: () => _openProject(ctx, m),
                        onRename: () => _rename(ctx, m),
                        onDelete: () => _delete(ctx, m),
                      );
                    },
                    childCount: c.projects.length,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ProjectCard extends StatelessWidget {
  const _ProjectCard({
    required this.meta,
    required this.repository,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
  });

  final ProjectMeta meta;
  final ProjectRepository repository;
  final VoidCallback onOpen, onRename, onDelete;

  @override
  Widget build(BuildContext context) {
    final thumb = meta.thumbnailPath;
    return Material(
      color: AppColors.panel,
      borderRadius: BorderRadius.circular(14),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onOpen,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const Checkerboard(),
                  if (thumb != null)
                    _Thumb(
                        repository: repository,
                        projectId: meta.id,
                        path: thumb),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(meta.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style:
                                const TextStyle(fontWeight: FontWeight.w600)),
                        Text(formatDateTime(meta.modifiedAt),
                            style: const TextStyle(
                                fontSize: 12, color: AppColors.textDim)),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (v) => v == 'rename' ? onRename() : onDelete(),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'rename', child: Text('Renomear')),
                      PopupMenuItem(value: 'delete', child: Text('Excluir')),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Thumb extends StatefulWidget {
  const _Thumb(
      {required this.repository, required this.projectId, required this.path});
  final ProjectRepository repository;
  final String projectId, path;

  @override
  State<_Thumb> createState() => _ThumbState();
}

class _ThumbState extends State<_Thumb> {
  late final Future<Uint8List> _bytes =
      widget.repository.loadAsset(widget.projectId, widget.path);

  @override
  Widget build(BuildContext context) => FutureBuilder<Uint8List>(
        future: _bytes,
        builder: (_, s) {
          if (!s.hasData) return const SizedBox.shrink();
          return Image.memory(
            s.data!,
            fit: BoxFit.contain,
            cacheWidth: 400,
            gaplessPlayback: true,
            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
          );
        },
      );
}

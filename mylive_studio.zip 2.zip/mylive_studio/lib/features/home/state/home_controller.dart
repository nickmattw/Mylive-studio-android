import 'package:flutter/foundation.dart';

import '../../project/models/project_meta.dart';
import '../../project/services/project_repository.dart';

class HomeController extends ChangeNotifier {
  HomeController(this.repository);

  final ProjectRepository repository;

  List<ProjectMeta> projects = [];
  bool loading = false;
  String? error;

  Future<void> load() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      projects = await repository.listProjects();
    } catch (e) {
      error = e.toString();
    }
    loading = false;
    notifyListeners();
  }

  Future<ProjectMeta> create({
    required String name,
    required int width,
    required int height,
    ImportedImage? initialImage,
  }) async {
    final meta = await repository.createProject(
        name: name, width: width, height: height, initialImage: initialImage);
    await load();
    return meta;
  }

  Future<void> rename(String id, String name) async {
    await repository.renameProject(id, name);
    await load();
  }

  Future<void> delete(String id) async {
    await repository.deleteProject(id);
    await load();
  }
}

#!/usr/bin/env bash
# Gera o APK debug do MyLive Studio. Requer Flutter + Android SDK instalados.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d android ]; then
  flutter create --platforms=android --org com.mylive --project-name mylive_studio .
fi
flutter pub get
flutter test
flutter build apk --debug
echo "APK: build/app/outputs/flutter-apk/app-debug.apk"
